# =========================================================
# COMMON IMPORTS
# =========================================================
import dlt
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.types import StructType, StructField, StringType

# =========================================================
# ========================= BRONZE ========================
# =========================================================

# ---------------- CUSTOMER ----------------
address_schema = StructType([
    StructField("street", StringType(), True),
    StructField("city", StringType(), True),
    StructField("state", StringType(), True),
    StructField("zip", StringType(), True)
])

@dlt.table(name="bronze_customers")
def bronze_customers():
    df = spark.read.json("/Volumes/insurance_project/bronze_schema/raw/customers/")
    dup_window = Window.partitionBy("customer_id")

    return (
        df
        .withColumn("dob", F.coalesce(
            F.to_date("dob","yyyy-MM-dd"),
            F.to_date("dob","dd-MM-yyyy"),
            F.to_date("dob","MM/dd/yyyy"),
            F.to_date("dob","yyyy/MM/dd"),
            F.to_date("dob","dd/MM/yyyy")
        ))
        .withColumn("updated_at", F.coalesce(
            F.to_timestamp("updated_at","yyyy-MM-dd HH:mm:ss"),
            F.to_timestamp("updated_at","yyyy-MM-dd'T'HH:mm:ss"),
            F.to_timestamp("updated_at","yyyy-MM-dd HH:mm:ss.SSS"),
            F.to_timestamp("updated_at")
        ))
        .withColumn("credit_score", F.col("credit_score").cast("int"))
        .withColumn("address_struct", F.from_json("address", address_schema))
        .withColumn("is_duplicate_customer", F.count("*").over(dup_window) > 1)
        .withColumn("invalid_credit_score",
            (F.col("credit_score") < 300) | (F.col("credit_score") > 850))
        .withColumn("invalid_dob",
            F.col("dob").isNull() & F.col("updated_at").isNotNull())
        .withColumn("invalid_address_json",
            F.col("address_struct").isNull() & F.col("address").isNotNull())
    )

# ---------------- POLICIES ----------------
@dlt.table(name="bronze_policies")
def bronze_policies():
    df = spark.read.json("/Volumes/insurance_project/bronze_schema/raw/policies/")
    dup_window = Window.partitionBy("policy_id")
    overlap_window = Window.partitionBy("customer_id","vehicle_id")

    return (
        df
        .withColumn("start_date", F.coalesce(
            F.to_date("start_date","yyyy-MM-dd"),
            F.to_date("start_date","dd-MM-yyyy"),
            F.to_date("start_date","MM/dd/yyyy")
        ))
        .withColumn("end_date", F.coalesce(
            F.to_date("end_date","yyyy-MM-dd"),
            F.to_date("end_date","dd-MM-yyyy"),
            F.to_date("end_date","MM/dd/yyyy")
        ))
        .withColumn("policy_type", F.upper("policy_type"))
        .withColumn("premium_amount", F.col("premium_amount").cast("double"))
        .withColumn("coverage_limit", F.col("coverage_limit").cast("double"))
        .withColumn("is_duplicate_policy", F.count("*").over(dup_window) > 1)
        .withColumn("invalid_premium_amount", F.col("premium_amount") < 0)
        .withColumn("invalid_coverage_limit", F.col("coverage_limit") < 0)
        .withColumn("invalid_policy_dates",
            F.col("start_date").isNull() |
            (F.col("end_date").isNotNull() & (F.col("start_date") > F.col("end_date"))))
        .withColumn("has_overlapping_policies",
            F.count("*").over(overlap_window) > 1)
    )

# ---------------- CLAIMS ----------------
@dlt.table(name="bronze_claims")
def bronze_claims():
    df = spark.read.json("/Volumes/insurance_project/bronze_schema/raw/claims/")
    dup_window = Window.partitionBy("claim_id")

    return (
        df
        .withColumn("incident_date", F.coalesce(
            F.to_date("incident_date","yyyy-MM-dd"),
            F.to_date("incident_date","dd-MM-yyyy"),
            F.to_date("incident_date","MM/dd/yyyy")
        ))
        .withColumn("filed_date", F.coalesce(
            F.to_date("filed_date","yyyy-MM-dd"),
            F.to_date("filed_date","dd-MM-yyyy"),
            F.to_date("filed_date","MM/dd/yyyy")
        ))
        .withColumn("claim_amount", F.col("claim_amount").cast("double"))
        .withColumn("status", F.upper("status"))
        .withColumn("claim_type", F.upper("claim_type"))
        .withColumn("is_duplicate_claim", F.count("*").over(dup_window) > 1)
        .withColumn("invalid_claim_amount", F.col("claim_amount") < 0)
        .withColumn("invalid_incident_date",
            F.col("incident_date").isNull() & F.col("filed_date").isNotNull())
    )

# ---------------- PAYOUTS ----------------
@dlt.table(name="bronze_payouts")
def bronze_payouts():
    df = spark.read.json("/Volumes/insurance_project/bronze_schema/raw/payouts/")

    return (
        df
        .withColumn("payment_date", F.coalesce(
            F.to_date("payment_date","yyyy-MM-dd"),
            F.to_date("payment_date","dd-MM-yyyy"),
            F.to_date("payment_date","MM/dd/yyyy")
        ))
        .withColumn("amount_paid", F.col("amount_paid").cast("double"))
        .withColumn("payment_method", F.upper("payment_method"))
        .withColumn("invalid_amount_paid", F.col("amount_paid") < 0)
        .withColumn("invalid_payment_date", F.col("payment_date").isNull())
    )

# ---------------- IOT ----------------
@dlt.table(name="bronze_iot_telematics")
def bronze_iot_telematics():
    df = spark.read.json("/Volumes/insurance_project/bronze_schema/raw/iot_telematics/")

    return (
        df
        .withColumn("timestamp", F.to_timestamp("timestamp"))
        .withColumn("speed", F.col("speed").cast("double"))
        .withColumn("mileage", F.col("mileage").cast("double"))
        .withColumn("hard_braking_event", F.col("hard_braking_event").cast("boolean"))
        .withColumn("invalid_speed", F.col("speed") < 0)
        .withColumn("invalid_mileage", F.col("mileage") < 0)
        .withColumn("invalid_timestamp", F.col("timestamp").isNull())
    )

# =========================================================
# ========================= SILVER ========================
# =========================================================

@dlt.table(name="dim_customers")
def dim_customers():
    df = dlt.read("bronze_customers")

    df = (
        df
        .withColumn("name_clean", F.lower(F.trim("name")))
        .withColumn("occupation_clean", F.initcap(F.trim("occupation")))
        .withColumn("credit_score",
            F.when(F.col("credit_score").between(300,850), F.col("credit_score")))
        .withColumn("street", F.col("address_struct.street"))
        .withColumn("city", F.col("address_struct.city"))
        .withColumn("state", F.col("address_struct.state"))
        .withColumn("zip_code", F.col("address_struct.zip"))
    )

    dedup_window = Window.partitionBy("name_clean","dob") \
        .orderBy(F.col("updated_at").desc())

    df = df.withColumn("rn", F.row_number().over(dedup_window)) \
           .filter("rn = 1").drop("rn")

    scd_window = Window.partitionBy("customer_id").orderBy("updated_at")

    df = (
        df
        .withColumn("valid_from", F.col("updated_at"))
        .withColumn("valid_to", F.lead("updated_at").over(scd_window))
        .withColumn("is_current", F.col("valid_to").isNull())
    )

    return df.select(
        "customer_id","name","dob","street","city","state","zip_code",
        "credit_score","occupation_clean",
        "valid_from","valid_to","is_current"
    )

@dlt.table(name="fact_policy_risk_profile")
def fact_policy_risk_profile():
    policies = dlt.read("bronze_policies")
    telematics = dlt.read("bronze_iot_telematics")
    customers = dlt.read("dim_customers").filter("is_current = true")

    tele_agg = telematics.groupBy("policy_id").agg(
        (F.max("mileage") - F.min("mileage")).alias("total_miles_driven"),
        F.sum(F.col("hard_braking_event").cast("int")).alias("hard_braking_count"),
        F.sum(F.when(F.col("speed") > 80, 1).otherwise(0))
            .alias("speeding_events_count")
    )

    df = policies.join(customers,"customer_id","inner") \
                 .join(tele_agg,"policy_id","left")

    df = df.withColumn(
        "risk_score",
        F.when(F.col("total_miles_driven") > 0,
            (F.col("hard_braking_count") + F.col("speeding_events_count")) /
            (F.col("total_miles_driven") / 100)
        ).otherwise(0)
    )

    return df.withColumn(
        "risk_category",
        F.when(F.col("risk_score") <= 2, "LOW")
         .when(F.col("risk_score") <= 5, "MEDIUM")
         .otherwise("HIGH")
    )

@dlt.table(name="fact_claims_lifecycle")
def fact_claims_lifecycle():
    claims = dlt.read("bronze_claims")
    policies = dlt.read("fact_policy_risk_profile")
    payouts = dlt.read("bronze_payouts")

    payout_agg = payouts.groupBy("claim_id").agg(
        F.sum("amount_paid").alias("total_amount_paid"),
        F.max("payment_date").alias("last_payment_date")
    )

    df = claims.join(policies,"policy_id","inner") \
               .join(payout_agg,"claim_id","left")

    df = df.withColumn(
        "is_valid_claim",
        F.col("incident_date")
         .between(F.col("start_date"), F.col("end_date"))
    )

    return df.withColumn(
        "status",
        F.when(
            (F.col("status") == "CLOSED") &
            (F.col("last_payment_date") > F.col("filed_date")),
            "REOPENED"
        ).otherwise(F.col("status"))
    )

# =========================================================
# ========================== GOLD =========================
# =========================================================

@dlt.table(name="kpi_loss_ratio")
def kpi_loss_ratio():
    p = dlt.read("fact_policy_risk_profile")
    cl = dlt.read("fact_claims_lifecycle")

    premiums = p.withColumn("date", F.trunc("start_date","month")) \
        .groupBy("date").agg(
            F.sum("premium_amount").alias("total_premiums_collected")
        )

    claims_paid = cl.filter("status='CLOSED'") \
        .withColumn("date", F.trunc("last_payment_date","month")) \
        .groupBy("date").agg(
            F.sum("total_amount_paid").alias("total_claims_paid")
        )

    claims_reserved = cl.filter("status IN ('OPEN','REOPENED')") \
        .withColumn("date", F.trunc("filed_date","month")) \
        .groupBy("date").agg(
            F.sum("claim_amount").alias("claims_reserved")
        )

    return premiums.join(claims_paid,"date","left") \
        .join(claims_reserved,"date","left") \
        .fillna(0) \
        .withColumn(
            "loss_ratio_percentage",
            ((F.col("total_claims_paid") + F.col("claims_reserved")) /
             F.col("total_premiums_collected")) * 100
        )

@dlt.table(name="kpi_claim_processing_lag")
def kpi_claim_processing_lag():
    cl = dlt.read("fact_claims_lifecycle")

    df = cl.filter("status='CLOSED'") \
        .withColumn("processing_days",
            F.datediff("last_payment_date","filed_date")) \
        .withColumn("date", F.trunc("filed_date","month"))

    return df.groupBy("date").agg(
        F.count("claim_id").alias("total_claims_processed"),
        F.avg("processing_days").alias("avg_processing_days"),
        F.expr("percentile_approx(processing_days, 0.5)")
            .alias("median_processing_days"),
        F.sum(F.when(F.col("processing_days") <= 30, 1).otherwise(0))
            .alias("claims_processed_within_30_days"),
        F.sum(F.when(F.col("processing_days") > 60, 1).otherwise(0))
            .alias("claims_processed_over_60_days")
    )

@dlt.table(name="kpi_premium_leakage_analysis")
def kpi_premium_leakage_analysis():
    p = dlt.read("fact_policy_risk_profile").alias("p")
    c = dlt.read("dim_customers").filter("is_current=true").alias("c")

    df = p.join(c, "customer_id", "inner") \
        .filter((p.end_date.isNull()) | (p.end_date > F.current_date()))

    w = Window.partitionBy("policy_type")

    df = df.withColumn(
        "premium_25th_percentile",
        F.expr("percentile_approx(premium_amount,0.25)").over(w)
    )

    df = df.withColumn(
        "expected_premium_midpoint",
        F.when(p.risk_category=="LOW",400)
         .when(p.risk_category=="MEDIUM",650)
         .otherwise(1150)
    )

    df = df.withColumn(
        "premium_leakage_amount",
        F.col("expected_premium_midpoint") - p.premium_amount
    )

    df = df.withColumn(
        "recommendation",
        F.when(F.col("premium_leakage_amount") > 0,
               "Increase Premium on Renewal")
         .otherwise("Review Policy")
    )

    return df.filter(
        ((p.risk_category=="HIGH") &
         (p.premium_amount <= F.col("premium_25th_percentile"))) |
        ((p.risk_score > 5) & (p.premium_amount < 500))
    )

@dlt.table(name="kpi_frequency_severity")
def kpi_frequency_severity():
    p = dlt.read("fact_policy_risk_profile")
    cl = dlt.read("fact_claims_lifecycle").filter("is_valid_claim=true")

    policy_counts = p.withColumn("date",F.trunc("start_date","month")) \
        .groupBy("date","policy_type") \
        .agg(F.countDistinct("policy_id").alias("total_policies"))

    claim_metrics = cl.withColumn("date",F.trunc("incident_date","month")) \
        .groupBy("date","policy_type") \
        .agg(
            F.count("claim_id").alias("total_claims"),
            F.sum("claim_amount").alias("total_claim_amount"),
            F.avg("claim_amount").alias("avg_claim_amount"),
            F.expr("percentile_approx(claim_amount,0.5)")
                .alias("median_claim_amount")
        )

    return policy_counts.join(
        claim_metrics, ["date","policy_type"], "left"
    ).withColumn(
        "claims_per_1000_policies",
        (F.col("total_claims") / F.col("total_policies")) * 1000
    )
