# Databricks notebook source
# MAGIC %md
# MAGIC # Insurance Analytics - Bronze Data Setup
# MAGIC
# MAGIC This notebook sets up the environment and generates bronze layer data for the Insurance Analytics project.
# MAGIC
# MAGIC It will:
# MAGIC - Create catalog: `insurance_project`
# MAGIC - Create schema: `bronze_schema`
# MAGIC - Create volume: `raw` within the schema
# MAGIC - Create folders for each bronze table in the volume
# MAGIC - Generate sample data files with **intentional data quality issues** for students to resolve
# MAGIC
# MAGIC **Bronze Tables:**
# MAGIC - `raw_policies`: Policy records (~3,000 rows)
# MAGIC - `raw_claims`: Claim records (~5,000 rows)
# MAGIC - `raw_customers`: Customer master data (~2,000 rows)
# MAGIC - `raw_iot_telematics`: IoT telematics data (~300,000 rows - ~100 per policy)
# MAGIC - `raw_payouts`: Payout records (~4,000 rows)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 1: Define Environment Variables

# COMMAND ----------

# Define catalog, schema, and volume names
CATALOG_NAME = 'insurance_project'
SCHEMA_NAME = 'bronze_schema'
VOLUME_NAME = 'raw'

# Define the base volume path
VOLUME_PATH = f'/Volumes/{CATALOG_NAME}/{SCHEMA_NAME}/{VOLUME_NAME}'

print(f'Catalog: {CATALOG_NAME}')
print(f'Schema: {SCHEMA_NAME}')
print(f'Volume: {VOLUME_NAME}')
print(f'Volume Path: {VOLUME_PATH}')

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 2: Create Catalog

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create catalog if it doesn't exist
# MAGIC CREATE CATALOG IF NOT EXISTS insurance_project;

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 3: Create Schema

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create schema within the catalog
# MAGIC CREATE SCHEMA IF NOT EXISTS insurance_project.bronze_schema;

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 4: Create Volume

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create volume within the schema
# MAGIC CREATE VOLUME IF NOT EXISTS insurance_project.bronze_schema.raw;

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 5: Create Directories in Volume

# COMMAND ----------

def create_directory_in_volume(volume_path: str, folder_names: list):
    '''
    Creates multiple directories in the specified volume path using dbutils.fs.
    
    Parameters:
    - volume_path (str): The base volume path
    - folder_names (list): A list of folder names to create
    '''
    print('----------------------------------------------------------------------------------------')
    for folder in folder_names:
        folder_path = f'{volume_path}/{folder}'
        try:
            # Try to list the directory to check if it exists
            dbutils.fs.ls(folder_path)
            print(f'Directory {folder_path} already exists. No action taken.')
        except:
            # Directory doesn't exist, create it
            dbutils.fs.mkdirs(folder_path)
            print(f'Creating folder: {folder_path}')
    print('----------------------------------------------------------------------------------------\n')

# Create folders for bronze tables
bronze_folders = ['policies', 'claims', 'customers', 'iot_telematics', 'payouts']
create_directory_in_volume(VOLUME_PATH, bronze_folders)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 6: Delete Existing Files (if resetting)

# COMMAND ----------

def delete_source_files(source_path: str):
    """
    Deletes all files in the specified source volume.
    
    Parameters:
    - source_path: The path to the volume containing the files to delete
    """
    print(f'\nSearching for files in {source_path} to delete...')
    try:
        files = dbutils.fs.ls(source_path)
        file_list = [f.path for f in files if not f.isDir()]
        if not file_list:
            print(f'No files found in {source_path}.\n')
        else:
            for file_path in file_list:
                print(f'Deleting file: {file_path}')
                dbutils.fs.rm(file_path)
    except Exception as e:
        print(f'Directory {source_path} does not exist or is empty: {e}')

# Delete existing files if resetting
for folder in bronze_folders:
    delete_source_files(f'{VOLUME_PATH}/{folder}/')

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 7: Install Faker Library

# COMMAND ----------

# Install Faker for generating realistic insurance data
%pip install faker

# COMMAND ----------

# MAGIC %restart_python 

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 8: Generate Sample Data with Data Quality Issues
# MAGIC
# MAGIC This step creates sample JSON files with **intentional data quality issues** that students must resolve:
# MAGIC
# MAGIC - **Duplicates**: Some records appear multiple times (especially customers with name variations)
# MAGIC - **Missing Values**: NULL values in critical fields
# MAGIC - **Invalid Formats**: Incorrect date formats, invalid numeric values, malformed JSON
# MAGIC - **Data Type Issues**: Numbers stored as strings, dates as strings in wrong format
# MAGIC - **Inconsistent Data**: Mixed case values, inconsistent codes
# MAGIC - **Orphaned Records**: References to non-existent entities
# MAGIC - **Outliers**: Extreme values that may indicate errors
# MAGIC - **Malformed JSON**: Invalid JSON structures in address field
# MAGIC - **Overlapping Policies**: Same customer with multiple active policies for different vehicles
# MAGIC - **Reopened Claims**: Claims marked "Closed" but new payouts arrive later
# MAGIC - **High Telematics Volume**: ~100 rows per policy requiring efficient aggregations
# MAGIC - **Date Discrepancies**: Claims with incident_date outside policy coverage period

# COMMAND ----------

def create_sample_data_with_issues():
    """
    Create sample JSON files with intentional data quality issues using Faker.
    
    Data includes:
    - raw_customers: ~2,000 records with duplicates, missing values, invalid dates, malformed JSON
    - raw_policies: ~3,000 records with overlapping policies, invalid dates, orphaned customer_ids
    - raw_claims: ~5,000 records with date discrepancies, invalid formats, orphaned policy_ids
    - raw_iot_telematics: ~300,000 records (~100 per policy) with high volume for aggregation challenge
    - raw_payouts: ~4,000 records with reopened claims scenario (payouts after claim closure)
    """
    import json
    import random
    from datetime import datetime, timedelta
    from faker import Faker
    
    fake = Faker()
    Faker.seed(42)  # For reproducibility
    random.seed(42)
    
    print("\n----------------Creating sample JSON files with data quality issues----------------")
    
    # Base date for generating timestamps (last 365 days)
    base_date = datetime(2024, 1, 1, 0, 0, 0)
    
    # ========== CUSTOMERS DATA ==========
    print("\n👥 Generating customers data...")
    occupations = ['Engineer', 'Teacher', 'Doctor', 'Lawyer', 'Nurse', 'Manager', 'Sales', 'Driver', 
                   'engineer', 'TEACHER', 'doctor', None]  # Mixed case and missing
    
    sample_customers = []
    customer_ids_used = set()
    customer_dob_map = {}  # Track DOB for duplicate customer generation
    
    for i in range(2000):
        customer_id = 1000 + i
        name = fake.name()
        
        # Issue: Some names have inconsistent casing or extra spaces
        if random.random() < 0.1:
            name = name.upper()  # All caps
        elif random.random() < 0.05:
            name = f"  {name}  "  # Extra spaces
        elif random.random() < 0.1:
            name = name.lower()  # All lowercase
        
        # Issue: Some DOBs are missing or invalid format
        if random.random() < 0.08:
            dob = None  # Missing DOB
        elif random.random() < 0.1:
            dob = (base_date - timedelta(days=random.randint(0, 36500))).strftime("%d/%m/%Y")  # Wrong format
        elif random.random() < 0.05:
            dob = "invalid-date"  # Invalid date
        else:
            dob = (base_date - timedelta(days=random.randint(18*365, 80*365))).strftime("%Y-%m-%d")
            customer_dob_map[customer_id] = dob
        
        # Issue: address sometimes malformed, missing, or invalid JSON
        if random.random() < 0.1:
            address = None  # Missing JSON
        elif random.random() < 0.1:
            address = "not a json"  # Invalid JSON string
        elif random.random() < 0.05:
            address = '{"street": "incomplete'  # Malformed JSON (unclosed)
        else:
            address = json.dumps({
                "street": fake.street_address(),
                "city": fake.city(),
                "state": fake.state_abbr(),
                "zip": fake.zipcode()
            })
        
        # Issue: Some credit scores are missing or out of range
        if random.random() < 0.08:
            credit_score = None  # Missing credit score
        elif random.random() < 0.05:
            credit_score = random.randint(-100, 299)  # Below valid range
        elif random.random() < 0.03:
            credit_score = random.randint(851, 1000)  # Above valid range
        else:
            credit_score = random.randint(300, 850)  # Valid range
        
        # Issue: Some occupations are missing or inconsistent
        occupation = random.choice(occupations)
        
        # Issue: Some timestamps are in wrong format
        if random.random() < 0.1:
            updated_at = (base_date + timedelta(days=random.randint(-365, 0))).strftime("%d/%m/%Y %H:%M")  # Wrong format
        elif random.random() < 0.05:
            updated_at = "invalid-timestamp"  # Invalid
        else:
            updated_at = (base_date + timedelta(days=random.randint(-365, 0))).strftime("%Y-%m-%dT%H:%M:%SZ")
        
        sample_customers.append({
            "customer_id": customer_id,
            "name": name,
            "dob": dob,
            "address": address,
            "credit_score": credit_score,
            "occupation": occupation,
            "updated_at": updated_at
        })
        customer_ids_used.add(customer_id)
    
    # Issue: Add duplicate customers with name variations (same DOB, similar names)
    print("  Adding duplicate customers with name variations...")
    for _ in range(80):  # Create 80 duplicate customer pairs
        original_customer = random.choice(sample_customers)
        if original_customer["dob"] and original_customer["dob"] != "invalid-date":
            # Create duplicate with name variation
            dup_customer = original_customer.copy()
            # Name variations: Jon vs John, Mike vs Michael, etc.
            name_variations = {
                "John": "Jon", "Jon": "John",
                "Michael": "Mike", "Mike": "Michael",
                "Robert": "Bob", "Bob": "Robert",
                "William": "Bill", "Bill": "William",
                "Richard": "Rick", "Rick": "Richard"
            }
            name_parts = dup_customer["name"].strip().split()
            if len(name_parts) > 0:
                first_name = name_parts[0]
                if first_name in name_variations:
                    name_parts[0] = name_variations[first_name]
                    dup_customer["name"] = " ".join(name_parts)
                elif random.random() < 0.5:
                    # Add typo
                    name_parts[0] = name_parts[0] + "x" if len(name_parts[0]) < 10 else name_parts[0][:-1]
                    dup_customer["name"] = " ".join(name_parts)
            
            # Slightly different customer_id but same DOB
            dup_customer["customer_id"] = 5000 + len(sample_customers)
            sample_customers.append(dup_customer)
    
    # Issue: Add exact duplicate records
    for _ in range(40):
        dup_customer = random.choice(sample_customers).copy()
        dup_customer["customer_id"] = 5000 + len(sample_customers)
        sample_customers.append(dup_customer)
    
    # ========== POLICIES DATA ==========
    print("\n📋 Generating policies data...")
    policy_types = ['Auto', 'Home', 'Life', 'Health', 'auto', 'HOME', 'life', None]  # Mixed case and missing
    
    sample_policies = []
    policy_ids_used = set()
    policy_customer_map = {}  # Track customer-policy relationships
    overlapping_policies_count = 0
    
    # Ensure we have valid customer_ids to reference
    valid_customer_ids = list(customer_ids_used)
    if not valid_customer_ids:
        raise ValueError("No customer_ids generated! Cannot create policies.")
    
    for i in range(3000):
        policy_id = 10000 + i
        
        # Issue: Some policies reference non-existent customers
        if random.random() < 0.05:
            customer_id = random.randint(10000, 20000)  # Non-existent customer
        else:
            customer_id = random.choice(valid_customer_ids)
        
        # Issue: Some policy types are missing or inconsistent
        policy_type = random.choice(policy_types)
        
        # Issue: Some premium amounts are missing, negative, or extreme outliers
        if random.random() < 0.08:
            premium_amount = None  # Missing premium
        elif random.random() < 0.05:
            premium_amount = round(random.uniform(-100, 0), 2)  # Negative premium
        elif random.random() < 0.03:
            premium_amount = round(random.uniform(100000, 500000), 2)  # Extreme outlier
        else:
            premium_amount = round(random.uniform(200, 2000), 2)  # Normal range
        
        # Issue: Some dates are in wrong format
        start_date = base_date + timedelta(days=random.randint(-365, 180))
        if random.random() < 0.1:
            start_date_str = start_date.strftime("%d/%m/%Y")  # Wrong format
        elif random.random() < 0.05:
            start_date_str = "invalid-date"  # Invalid
        else:
            start_date_str = start_date.strftime("%Y-%m-%d")
        
        # Issue: Some policies are active (end_date = NULL), some expired
        if random.random() < 0.4:
            end_date_str = None  # Active policy
        else:
            end_date = start_date + timedelta(days=random.randint(30, 1095))  # 1 month to 3 years
            if random.random() < 0.1:
                end_date_str = end_date.strftime("%m-%d-%Y")  # Wrong format
            elif random.random() < 0.05:
                end_date_str = "invalid"  # Invalid
            else:
                end_date_str = end_date.strftime("%Y-%m-%d")
        
        # Issue: Some coverage limits are missing or invalid
        if random.random() < 0.08:
            coverage_limit = None  # Missing coverage
        elif random.random() < 0.05:
            coverage_limit = round(random.uniform(-1000, 0), 2)  # Negative
        else:
            coverage_limit = round(random.uniform(10000, 500000), 2)  # Normal range
        
        # Vehicle ID for auto policies
        if policy_type and policy_type.lower() == 'auto':
            vehicle_id = f"VH-{random.randint(1000, 9999)}"
        else:
            vehicle_id = None
        
        sample_policies.append({
            "policy_id": policy_id,
            "customer_id": customer_id,
            "policy_type": policy_type,
            "premium_amount": premium_amount,
            "start_date": start_date_str,
            "end_date": end_date_str,
            "coverage_limit": coverage_limit,
            "vehicle_id": vehicle_id
        })
        policy_ids_used.add(policy_id)
        
        # Track customer-policy relationships for overlapping policies
        if customer_id not in policy_customer_map:
            policy_customer_map[customer_id] = []
        policy_customer_map[customer_id].append(policy_id)
    
    # Issue: Add overlapping policies (same customer, different vehicles, overlapping dates)
    print("  Adding overlapping policies for same customers...")
    for customer_id, policy_list in policy_customer_map.items():
        if len(policy_list) >= 1 and random.random() < 0.15:  # 15% of customers with multiple policies get overlapping ones
            # Get an existing policy for this customer
            existing_policy_id = random.choice(policy_list)
            existing_policy = next(p for p in sample_policies if p["policy_id"] == existing_policy_id)
            
            if existing_policy["policy_type"] and existing_policy["policy_type"].lower() == 'auto' and existing_policy["vehicle_id"]:
                # Create overlapping policy with different vehicle
                new_vehicle_id = f"VH-{random.randint(1000, 9999)}"
                while new_vehicle_id == existing_policy["vehicle_id"]:
                    new_vehicle_id = f"VH-{random.randint(1000, 9999)}"
                
                # Create policy with overlapping dates
                new_policy_id = 20000 + len(sample_policies)
                new_start = datetime.strptime(existing_policy["start_date"], "%Y-%m-%d") if existing_policy["start_date"] and existing_policy["start_date"] != "invalid-date" and "/" not in existing_policy["start_date"] else base_date
                new_start = new_start + timedelta(days=random.randint(-30, 30))  # Overlap by starting within 30 days
                new_end = new_start + timedelta(days=random.randint(365, 1095))
                
                sample_policies.append({
                    "policy_id": new_policy_id,
                    "customer_id": customer_id,
                    "policy_type": "Auto",
                    "premium_amount": round(random.uniform(200, 2000), 2),
                    "start_date": new_start.strftime("%Y-%m-%d"),
                    "end_date": new_end.strftime("%Y-%m-%d"),
                    "coverage_limit": round(random.uniform(10000, 500000), 2),
                    "vehicle_id": new_vehicle_id
                })
                policy_ids_used.add(new_policy_id)
                overlapping_policies_count += 1
    
    print(f"  Created {overlapping_policies_count} overlapping policies")
    
    # Issue: Add duplicate policies
    for _ in range(100):
        dup_policy = random.choice(sample_policies).copy()
        dup_policy["policy_id"] = 20000 + len(sample_policies)
        sample_policies.append(dup_policy)
        policy_ids_used.add(dup_policy["policy_id"])
    
    # ========== CLAIMS DATA ==========
    print("\n🚨 Generating claims data...")
    claim_statuses = ['Open', 'Closed', 'Denied', 'Reopened', 'open', 'CLOSED', 'denied', None]  # Mixed case and missing
    claim_types = ['Accident', 'Theft', 'Damage', 'Medical', 'Liability', 'accident', 'THEFT', None]
    
    sample_claims = []
    claim_ids_used = set()
    claim_policy_map = {}  # Track claim-policy relationships for date validation
    claims_with_date_issues = 0
    
    # Ensure we have valid policy_ids to reference
    valid_policy_ids = list(policy_ids_used)
    if not valid_policy_ids:
        raise ValueError("No policy_ids generated! Cannot create claims.")
    
    for i in range(5000):
        claim_id = 30000 + i
        
        # Issue: Some claims reference non-existent policies
        if random.random() < 0.05:
            policy_id = random.randint(50000, 60000)  # Non-existent policy
        else:
            policy_id = random.choice(valid_policy_ids)
        
        # Get policy dates for validation
        policy = next((p for p in sample_policies if p["policy_id"] == policy_id), None)
        policy_start = None
        policy_end = None
        
        if policy:
            try:
                if policy["start_date"] and policy["start_date"] != "invalid-date" and "/" not in policy["start_date"] and "-" not in policy["start_date"][:4]:
                    policy_start = datetime.strptime(policy["start_date"], "%Y-%m-%d")
                if policy["end_date"] and policy["end_date"] != "invalid" and "/" not in policy["end_date"]:
                    policy_end = datetime.strptime(policy["end_date"], "%Y-%m-%d")
            except:
                pass
        
        # Issue: Date discrepancies - some incident dates outside policy coverage period
        if policy_start and random.random() < 0.15:  # 15% have date issues
            # Incident date before policy start or after policy end
            if random.random() < 0.5 and policy_start:
                incident_date = policy_start - timedelta(days=random.randint(1, 90))  # Before policy start
            elif policy_end:
                incident_date = policy_end + timedelta(days=random.randint(1, 90))  # After policy end
            else:
                incident_date = base_date + timedelta(days=random.randint(0, 365))
            claims_with_date_issues += 1
        else:
            # Normal incident date within policy period
            if policy_start:
                if policy_end:
                    incident_date = policy_start + timedelta(days=random.randint(0, (policy_end - policy_start).days))
                else:
                    incident_date = policy_start + timedelta(days=random.randint(0, 365))
            else:
                incident_date = base_date + timedelta(days=random.randint(0, 365))
        
        # Issue: Some dates are in wrong format
        if random.random() < 0.1:
            incident_date_str = incident_date.strftime("%d/%m/%Y")  # Wrong format
        elif random.random() < 0.05:
            incident_date_str = "invalid-date"  # Invalid
        else:
            incident_date_str = incident_date.strftime("%Y-%m-%d")
        
        # Filed date is usually after incident date
        filed_date = incident_date + timedelta(days=random.randint(0, 30))
        if random.random() < 0.1:
            filed_date_str = filed_date.strftime("%m-%d-%Y")  # Wrong format
        elif random.random() < 0.05:
            filed_date_str = "invalid"  # Invalid
        else:
            filed_date_str = filed_date.strftime("%Y-%m-%d")
        
        # Issue: Some claim amounts are missing, negative, or extreme outliers
        if random.random() < 0.08:
            claim_amount = None  # Missing amount
        elif random.random() < 0.05:
            claim_amount = round(random.uniform(-1000, 0), 2)  # Negative amount
        elif random.random() < 0.03:
            claim_amount = round(random.uniform(1000000, 5000000), 2)  # Extreme outlier
        else:
            claim_amount = round(random.uniform(500, 50000), 2)  # Normal range
        
        # Issue: Some statuses are missing or inconsistent
        status = random.choice(claim_statuses)
        claim_type = random.choice(claim_types)
        
        sample_claims.append({
            "claim_id": claim_id,
            "policy_id": policy_id,
            "incident_date": incident_date_str,
            "filed_date": filed_date_str,
            "claim_amount": claim_amount,
            "status": status,
            "claim_type": claim_type
        })
        claim_ids_used.add(claim_id)
        claim_policy_map[claim_id] = {
            "policy_id": policy_id,
            "incident_date": incident_date,
            "filed_date": filed_date,
            "status": status
        }
    
    print(f"  Created {claims_with_date_issues} claims with date discrepancies (outside policy coverage)")
    
    # Issue: Add duplicate claims
    for _ in range(150):
        dup_claim = random.choice(sample_claims).copy()
        dup_claim["claim_id"] = 40000 + len(sample_claims)
        sample_claims.append(dup_claim)
        claim_ids_used.add(dup_claim["claim_id"])
        # Also add to claim_policy_map for proper foreign key tracking and reopened claims logic
        original_claim_id = dup_claim.get("policy_id")  # Get the original policy_id
        try:
            # Parse dates from the duplicate claim
            incident_date_parsed = base_date
            filed_date_parsed = base_date
            if dup_claim["incident_date"] and dup_claim["incident_date"] != "invalid-date":
                try:
                    if "/" not in dup_claim["incident_date"]:
                        incident_date_parsed = datetime.strptime(dup_claim["incident_date"], "%Y-%m-%d")
                except:
                    pass
            if dup_claim["filed_date"] and dup_claim["filed_date"] != "invalid":
                try:
                    if "/" not in dup_claim["filed_date"]:
                        filed_date_parsed = datetime.strptime(dup_claim["filed_date"], "%Y-%m-%d")
                except:
                    pass
            claim_policy_map[dup_claim["claim_id"]] = {
                "policy_id": original_claim_id,
                "incident_date": incident_date_parsed,
                "filed_date": filed_date_parsed,
                "status": dup_claim["status"]
            }
        except:
            # Fallback if parsing fails
            claim_policy_map[dup_claim["claim_id"]] = {
                "policy_id": original_claim_id,
                "incident_date": base_date,
                "filed_date": base_date,
                "status": dup_claim.get("status", "Open")
            }
    
    # ========== IOT TELEMATICS DATA ==========
    print("\n🚗 Generating IoT telematics data (high volume - ~100 rows per policy)...")
    sample_telematics = []
    telematics_per_policy = {}  # Track telematics per policy
    
    # Ensure we have valid policy_ids (only auto policies should have telematics)
    auto_policy_ids = [p["policy_id"] for p in sample_policies if p["policy_type"] and p["policy_type"].lower() == 'auto']
    
    if not auto_policy_ids:
        raise ValueError("No auto policies generated! Cannot create telematics data.")
    
    # Generate ~100 rows per policy for high volume challenge
    total_telematics_rows = 0
    for policy_id in auto_policy_ids:
        rows_for_policy = random.randint(80, 120)  # ~100 rows per policy
        telematics_per_policy[policy_id] = rows_for_policy
        total_telematics_rows += rows_for_policy
        
        # Get policy start date for timestamp generation
        policy = next((p for p in sample_policies if p["policy_id"] == policy_id), None)
        policy_start = base_date
        if policy and policy["start_date"] and policy["start_date"] != "invalid-date":
            try:
                if "/" not in policy["start_date"] and "-" not in policy["start_date"][:4]:
                    policy_start = datetime.strptime(policy["start_date"], "%Y-%m-%d")
            except:
                pass
        
        device_id = f"DEV-{policy_id}"
        base_mileage = random.randint(0, 50000)
        cumulative_mileage = base_mileage
        
        for row_num in range(rows_for_policy):
            telematics_id = 50000 + total_telematics_rows - rows_for_policy + row_num
            
            # Issue: Some telematics reference non-existent policies (5%)
            if random.random() < 0.05:
                ref_policy_id = random.randint(70000, 80000)  # Non-existent policy
            else:
                ref_policy_id = policy_id
            
            # Timestamp within policy period
            timestamp = policy_start + timedelta(days=random.randint(0, 180), hours=random.randint(0, 23), minutes=random.randint(0, 59))
            if random.random() < 0.1:
                timestamp_str = timestamp.strftime("%d/%m/%Y %H:%M:%S")  # Wrong format
            elif random.random() < 0.05:
                timestamp_str = "invalid-timestamp"  # Invalid
            else:
                timestamp_str = timestamp.strftime("%Y-%m-%dT%H:%M:%SZ")
            
            # Issue: Some speeds are missing, negative, or extreme outliers
            if random.random() < 0.08:
                speed = None  # Missing speed
            elif random.random() < 0.05:
                speed = round(random.uniform(-10, 0), 2)  # Negative speed
            elif random.random() < 0.03:
                speed = round(random.uniform(200, 300), 2)  # Extreme outlier
            else:
                speed = round(random.uniform(0, 100), 2)  # Normal range (0-100 mph)
            
            # Hard braking event (boolean, but stored as string/int sometimes)
            if random.random() < 0.08:
                hard_braking_event = None  # Missing
            elif random.random() < 0.1:
                hard_braking_event = "true"  # String instead of boolean
            elif random.random() < 0.05:
                hard_braking_event = "false"  # String instead of boolean
            elif random.random() < 0.05:
                hard_braking_event = 1  # Integer instead of boolean
            else:
                hard_braking_event = random.random() < 0.15  # 15% chance of hard braking
            
            # Cumulative mileage (increasing)
            cumulative_mileage += random.randint(1, 50)
            if random.random() < 0.08:
                mileage = None  # Missing mileage
            elif random.random() < 0.05:
                mileage = round(random.uniform(-100, 0), 2)  # Negative mileage
            else:
                mileage = cumulative_mileage
            
            sample_telematics.append({
                "device_id": device_id,
                "policy_id": ref_policy_id,
                "timestamp": timestamp_str,
                "speed": speed,
                "hard_braking_event": hard_braking_event,
                "mileage": mileage
            })
    
    print(f"  Generated {total_telematics_rows} telematics records (~{total_telematics_rows // len(auto_policy_ids)} per auto policy)")
    
    # Issue: Add duplicate telematics records
    for _ in range(500):
        dup_telematics = random.choice(sample_telematics).copy()
        sample_telematics.append(dup_telematics)
    
    # ========== PAYOUTS DATA ==========
    print("\n💰 Generating payouts data (including reopened claims scenario)...")
    payment_methods = ['Check', 'Wire', 'ACH', 'Credit', 'check', 'WIRE', 'ach', None]  # Mixed case and missing
    
    sample_payouts = []
    payout_per_claim = {}  # Track payouts per claim for reopened claims logic
    reopened_claims_count = 0
    
    # Ensure we have valid claim_ids to reference
    valid_claim_ids = list(claim_ids_used)
    if not valid_claim_ids:
        raise ValueError("No claim_ids generated! Cannot create payouts.")
    
    for i in range(4000):
        payout_id = 60000 + i
        
        # Issue: Some payouts reference non-existent claims
        if random.random() < 0.05:
            claim_id = random.randint(90000, 100000)  # Non-existent claim
        else:
            claim_id = random.choice(valid_claim_ids)
        
        # Get claim information
        claim_info = claim_policy_map.get(claim_id, {})
        claim_filed_date = claim_info.get("filed_date", base_date)
        claim_status = claim_info.get("status", "Open")
        
        # Track payouts per claim
        if claim_id not in payout_per_claim:
            payout_per_claim[claim_id] = []
        
        # Issue: Reopened claims - payout arrives after claim was marked "Closed"
        if claim_status and claim_status.lower() == 'closed' and random.random() < 0.2:  # 20% of closed claims get reopened
            # Payment date is 30-180 days after filed date (reopened scenario)
            payment_date = claim_filed_date + timedelta(days=random.randint(30, 180))
            reopened_claims_count += 1
        else:
            # Normal payment date (within 30 days of filed date)
            payment_date = claim_filed_date + timedelta(days=random.randint(0, 30))
        
        # Issue: Some dates are in wrong format
        if random.random() < 0.1:
            payment_date_str = payment_date.strftime("%d/%m/%Y")  # Wrong format
        elif random.random() < 0.05:
            payment_date_str = "invalid-date"  # Invalid
        else:
            payment_date_str = payment_date.strftime("%Y-%m-%d")
        
        # Issue: Some amounts are missing, negative, or extreme outliers
        if random.random() < 0.08:
            amount_paid = None  # Missing amount
        elif random.random() < 0.05:
            amount_paid = round(random.uniform(-500, 0), 2)  # Negative amount
        elif random.random() < 0.03:
            amount_paid = round(random.uniform(500000, 2000000), 2)  # Extreme outlier
        else:
            amount_paid = round(random.uniform(100, 30000), 2)  # Normal range
        
        # Issue: Some payment methods are missing or inconsistent
        payment_method = random.choice(payment_methods)
        
        sample_payouts.append({
            "payout_id": payout_id,
            "claim_id": claim_id,
            "payment_date": payment_date_str,
            "amount_paid": amount_paid,
            "payment_method": payment_method
        })
        payout_per_claim[claim_id].append({
            "payout_id": payout_id,
            "payment_date": payment_date,
            "amount_paid": amount_paid
        })
    
    print(f"  Generated {reopened_claims_count} payouts that reopen closed claims (payment after closure)")
    
    # Issue: Add duplicate payouts
    for _ in range(100):
        dup_payout = random.choice(sample_payouts).copy()
        dup_payout["payout_id"] = 70000 + len(sample_payouts)
        sample_payouts.append(dup_payout)
    
    # Write files using dbutils.fs.put (newline-delimited JSON)
    try:
        # Customers file
        customers_file = f'/Volumes/insurance_project/bronze_schema/raw/customers/00.json'
        customers_json_lines = [json.dumps(customer) for customer in sample_customers]
        customers_content = '\n'.join(customers_json_lines)
        dbutils.fs.put(customers_file, customers_content, overwrite=True)
        print(f'\n✅ Created customers file: {customers_file} ({len(sample_customers)} records)')
        
        # Policies file (split into multiple files)
        policies_per_file = 1000
        num_policy_files = (len(sample_policies) + policies_per_file - 1) // policies_per_file
        for file_num in range(num_policy_files):
            start_idx = file_num * policies_per_file
            end_idx = min(start_idx + policies_per_file, len(sample_policies))
            file_policies = sample_policies[start_idx:end_idx]
            policies_file = f'/Volumes/insurance_project/bronze_schema/raw/policies/{file_num:02d}.json'
            policies_json_lines = [json.dumps(policy) for policy in file_policies]
            policies_content = '\n'.join(policies_json_lines)
            dbutils.fs.put(policies_file, policies_content, overwrite=True)
            print(f'✅ Created policies file: {policies_file} ({len(file_policies)} records)')
        
        # Claims file (split into multiple files)
        claims_per_file = 1500
        num_claim_files = (len(sample_claims) + claims_per_file - 1) // claims_per_file
        for file_num in range(num_claim_files):
            start_idx = file_num * claims_per_file
            end_idx = min(start_idx + claims_per_file, len(sample_claims))
            file_claims = sample_claims[start_idx:end_idx]
            claims_file = f'/Volumes/insurance_project/bronze_schema/raw/claims/{file_num:02d}.json'
            claims_json_lines = [json.dumps(claim) for claim in file_claims]
            claims_content = '\n'.join(claims_json_lines)
            dbutils.fs.put(claims_file, claims_content, overwrite=True)
            print(f'✅ Created claims file: {claims_file} ({len(file_claims)} records)')
        
        # Telematics file (split into multiple files due to high volume)
        telematics_per_file = 50000
        num_telematics_files = (len(sample_telematics) + telematics_per_file - 1) // telematics_per_file
        for file_num in range(num_telematics_files):
            start_idx = file_num * telematics_per_file
            end_idx = min(start_idx + telematics_per_file, len(sample_telematics))
            file_telematics = sample_telematics[start_idx:end_idx]
            telematics_file = f'/Volumes/insurance_project/bronze_schema/raw/iot_telematics/{file_num:02d}.json'
            telematics_json_lines = [json.dumps(telematics) for telematics in file_telematics]
            telematics_content = '\n'.join(telematics_json_lines)
            dbutils.fs.put(telematics_file, telematics_content, overwrite=True)
            print(f'✅ Created telematics file: {telematics_file} ({len(file_telematics)} records)')
        
        # Payouts file (split into multiple files)
        payouts_per_file = 1500
        num_payout_files = (len(sample_payouts) + payouts_per_file - 1) // payouts_per_file
        for file_num in range(num_payout_files):
            start_idx = file_num * payouts_per_file
            end_idx = min(start_idx + payouts_per_file, len(sample_payouts))
            file_payouts = sample_payouts[start_idx:end_idx]
            payouts_file = f'/Volumes/insurance_project/bronze_schema/raw/payouts/{file_num:02d}.json'
            payouts_json_lines = [json.dumps(payout) for payout in file_payouts]
            payouts_content = '\n'.join(payouts_json_lines)
            dbutils.fs.put(payouts_file, payouts_content, overwrite=True)
            print(f'✅ Created payouts file: {payouts_file} ({len(file_payouts)} records)')
        
        print(f'\n📊 Total records generated:')
        print(f'  - Customers: {len(sample_customers)} records (customer_id: 1000-2999, plus duplicates)')
        print(f'  - Policies: {len(sample_policies)} records (policy_id: 10000-12999, plus overlapping and duplicates)')
        print(f'  - Claims: {len(sample_claims)} records (claim_id: 30000-34999, plus duplicates)')
        print(f'  - Telematics: {len(sample_telematics)} records (~100 per auto policy)')
        print(f'  - Payouts: {len(sample_payouts)} records (payout_id: 60000+)')
        
        # Print relationship summary for verification
        print(f'\n📋 Data Relationship Summary:')
        print(f'  - Customers: {len(sample_customers)} records')
        print(f'    → Includes ~80 duplicate customers with name variations (same DOB)')
        print(f'  - Policies: {len(sample_policies)} records')
        print(f'    → References customer_id from customers (95% valid, 5% orphaned)')
        print(f'    → {overlapping_policies_count} overlapping policies (same customer, different vehicles)')
        print(f'  - Claims: {len(sample_claims)} records')
        print(f'    → References policy_id from policies (95% valid, 5% orphaned)')
        print(f'    → {claims_with_date_issues} claims with date discrepancies (outside policy coverage)')
        print(f'  - Telematics: {len(sample_telematics)} records')
        print(f'    → References policy_id from policies (95% valid, 5% orphaned)')
        print(f'    → High volume: ~100 rows per auto policy (aggregation challenge)')
        print(f'  - Payouts: {len(sample_payouts)} records')
        print(f'    → References claim_id from claims (95% valid, 5% orphaned)')
        print(f'    → {reopened_claims_count} payouts that reopen closed claims')
        print(f'\n💡 Join Relationships (Foreign Key Integrity):')
        print(f'  - policies → customers (via customer_id)')
        print(f'    → 95% of policies reference valid customer_ids from customers table')
        print(f'    → 5% orphaned (intentional for data quality challenge)')
        print(f'  - claims → policies (via policy_id)')
        print(f'    → 95% of claims reference valid policy_ids from policies table')
        print(f'    → 5% orphaned (intentional for data quality challenge)')
        print(f'  - iot_telematics → policies (via policy_id)')
        print(f'    → 95% of telematics reference valid policy_ids (auto policies only)')
        print(f'    → 5% orphaned (intentional for data quality challenge)')
        print(f'  - payouts → claims (via claim_id)')
        print(f'    → 95% of payouts reference valid claim_ids from claims table')
        print(f'    → 5% orphaned (intentional for data quality challenge)')
        print(f'\n✅ Foreign Key Relationships: All valid references (95%) have matching keys for successful joins!')
        
        return True
    except Exception as e:
        print(f'❌ Error creating sample files: {e}')
        import traceback
        traceback.print_exc()
        return False

# Create sample JSON files with data quality issues
print('\n📝 Creating sample JSON files with intentional data quality issues...')
sample_created = create_sample_data_with_issues()

if sample_created:
    print('\n✅ Successfully created all sample JSON files!')
    print(f'\nFiles created in: /Volumes/insurance_project/bronze_schema/raw')
    print('  - customers/00.json (~2,120 customers with data issues)')
    print('  - policies/*.json (~3,100 policies with data issues, including overlapping)')
    print('  - claims/*.json (~5,150 claims with data issues, including date discrepancies)')
    print('  - iot_telematics/*.json (~300,500 telematics records - high volume challenge)')
    print('  - payouts/*.json (~4,100 payouts with data issues, including reopened claims)')
    print('\n⚠️  Note: These files contain intentional data quality issues that you must resolve!')
    print('\n💡 Tip: Use Auto Loader with schema evolution and rescued data column to handle malformed records.')
else:
    print('\n❌ Could not create sample files automatically.')

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 9: Verify Setup

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify catalog exists
# MAGIC SHOW CATALOGS LIKE 'insurance_project';

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify schema exists
# MAGIC SHOW SCHEMAS IN insurance_project LIKE 'bronze_schema';

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Verify volume exists
# MAGIC SHOW VOLUMES IN insurance_project.bronze_schema LIKE 'raw';

# COMMAND ----------

# Define bronze_folders to avoid NameError
bronze_folders = ['policies', 'claims', 'customers', 'iot_telematics', 'payouts']

# Verify folders and files
print(f'\nVerifying volume structure:')
print(f'Volume path: /Volumes/insurance_project/bronze_schema/raw')
print(f'\nFolders:')
for folder in bronze_folders:
    folder_path = f'/Volumes/insurance_project/bronze_schema/raw/{folder}'
    try:
        files = dbutils.fs.ls(folder_path)
        file_list = [f.name for f in files if not f.isDir()]
        total_size = sum(f.size for f in files if not f.isDir())
        print(f'  {folder}/: {len(file_list)} file(s), {total_size:,} bytes')
        if file_list:
            for file in sorted(file_list)[:3]:  # Show first 3 files
                print(f'    - {file}')
            if len(file_list) > 3:
                print(f'    ... and {len(file_list) - 3} more file(s)')
    except Exception as e:
        print(f'  {folder}/: NOT FOUND or ERROR - {e}')

# COMMAND ----------

# MAGIC %md
# MAGIC ## Setup Complete!
# MAGIC
# MAGIC Your environment is now configured with:
# MAGIC - Catalog: `insurance_project`
# MAGIC - Schema: `bronze_schema`
# MAGIC - Volume: `raw` at `/Volumes/insurance_project/bronze_schema/raw`
# MAGIC - Folders: `policies`, `claims`, `customers`, `iot_telematics`, `payouts`
# MAGIC
# MAGIC **Bronze Data Summary:**
# MAGIC - `raw_customers`: ~2,120 records (includes duplicate customers with name variations)
# MAGIC - `raw_policies`: ~3,100 records (includes overlapping policies for same customers with different vehicles)
# MAGIC - `raw_claims`: ~5,150 records (includes claims with date discrepancies outside policy coverage)
# MAGIC - `raw_iot_telematics`: ~300,500 records (~100 per auto policy - high volume aggregation challenge)
# MAGIC - `raw_payouts`: ~4,100 records (includes payouts that reopen closed claims)
# MAGIC
# MAGIC **⚠️ Important:** The sample data contains intentional data quality issues that you must identify and resolve in your pipeline:
# MAGIC - Missing values (NULL)
# MAGIC - Duplicate records (especially customers with name variations like "Jon Doe" vs "John Doe" with same DOB)
# MAGIC - Invalid date/timestamp formats
# MAGIC - Out-of-range values (negative amounts, invalid credit scores, etc.)
# MAGIC - Inconsistent case (mixed uppercase/lowercase)
# MAGIC - Orphaned records (references to non-existent entities)
# MAGIC - Malformed JSON in `address` field
# MAGIC - **Overlapping policies**: Same customer with multiple active policies for different vehicles
# MAGIC - **Reopened claims**: Claims marked "Closed" but new payouts arrive later (payment_date > closure date)
# MAGIC - **High telematics volume**: ~100 rows per policy requiring efficient aggregations
# MAGIC - **Date discrepancies**: Claims with incident_date outside policy coverage period (fraud/invalid claim flags)
# MAGIC - Data type issues (numbers as strings, wrong formats, boolean as string/int)
# MAGIC
# MAGIC **💡 Key Techniques to Use:**
# MAGIC - Auto Loader with schema evolution
# MAGIC - Rescued data column for malformed records
# MAGIC - PySpark functions for data cleaning (filter, when, regexp_replace, etc.)
# MAGIC - Customer deduplication logic (same DOB + name similarity)
# MAGIC - SCD Type 2 implementation for customer history tracking
# MAGIC - Efficient aggregation of high-volume telematics data before joining
# MAGIC - Validation of claims against policy coverage periods
# MAGIC - Handling of reopened claims logic
# MAGIC - Data quality checks and validations
# MAGIC
# MAGIC You can now proceed to the requirements notebook to understand the project objectives.