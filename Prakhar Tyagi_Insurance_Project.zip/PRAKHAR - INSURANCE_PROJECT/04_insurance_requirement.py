# Databricks notebook source
# MAGIC %md
# MAGIC # Insurance Analytics - End-to-End Project Requirements
# MAGIC
# MAGIC ## Project Overview
# MAGIC
# MAGIC You are a data engineer working for a large insurance company. Your task is to build a complete data pipeline that processes raw policy data, claims, customer information, IoT telematics data, and payout records from multiple source systems (Policy Admin System, Claims Portal, CRM, In-Car Sensors, Finance/ERP) to create business intelligence dashboards for insurance executives and underwriters.
# MAGIC
# MAGIC The project follows the **Medallion Architecture** pattern:
# MAGIC - **🥉 Bronze**: Raw ingestion layer (provided)
# MAGIC - **🥈 Silver**: Cleaned and conformed data layer (your task)
# MAGIC - **🥇 Gold**: Business intelligence and analytics layer (your task)
# MAGIC
# MAGIC **Technology Stack:**
# MAGIC - Databricks (Free Edition - Unity Catalog & Volumes)
# MAGIC - PySpark
# MAGIC - Delta Lake
# MAGIC - Auto Loader (for streaming/batch ingestion)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 🥉 Bronze Layer (Provided)
# MAGIC
# MAGIC The bronze layer contains raw data files in JSON format with **intentional data quality issues**. These are stored in Unity Catalog Volumes.
# MAGIC
# MAGIC ### Bronze Tables:
# MAGIC
# MAGIC 1. **`raw_policies`** (~3,000 rows - Policy Records)
# MAGIC    - `policy_id`: Unique policy identifier
# MAGIC    - `customer_id`: Reference to customer
# MAGIC    - `policy_type`: Type of policy (Auto, Home, Life, Health)
# MAGIC    - `premium_amount`: Monthly/annual premium amount
# MAGIC    - `start_date`: Policy start date
# MAGIC    - `end_date`: Policy end date (NULL for active policies)
# MAGIC    - `coverage_limit`: Maximum coverage amount
# MAGIC    - `vehicle_id`: Vehicle identifier (for auto policies, NULL for others)
# MAGIC
# MAGIC 2. **`raw_claims`** (~5,000 rows - Claim Records)
# MAGIC    - `claim_id`: Unique claim identifier
# MAGIC    - `policy_id`: Reference to policy
# MAGIC    - `incident_date`: Date when incident occurred
# MAGIC    - `filed_date`: Date when claim was filed
# MAGIC    - `claim_amount`: Total claim amount requested
# MAGIC    - `status`: Claim status (Open, Closed, Denied, Reopened)
# MAGIC    - `claim_type`: Type of claim (Accident, Theft, Damage, Medical, etc.)
# MAGIC
# MAGIC 3. **`raw_customers`** (~2,000 rows - Customer Master Data)
# MAGIC    - `customer_id`: Unique customer identifier
# MAGIC    - `name`: Customer full name
# MAGIC    - `dob`: Date of birth
# MAGIC    - `address`: Customer address (JSON string with street, city, state, zip)
# MAGIC    - `credit_score`: Credit score (300-850)
# MAGIC    - `occupation`: Customer occupation
# MAGIC    - `updated_at`: Last update timestamp
# MAGIC
# MAGIC 4. **`raw_iot_telematics`** (~300,000 rows - IoT Telematics Data)
# MAGIC    - `device_id`: Unique device identifier
# MAGIC    - `policy_id`: Reference to policy
# MAGIC    - `timestamp`: When telematics data was recorded
# MAGIC    - `speed`: Vehicle speed in mph
# MAGIC    - `hard_braking_event`: Boolean flag for hard braking incidents
# MAGIC    - `mileage`: Cumulative mileage at timestamp
# MAGIC
# MAGIC 5. **`raw_payouts`** (~4,000 rows - Payout Records)
# MAGIC    - `payout_id`: Unique payout identifier
# MAGIC    - `claim_id`: Reference to claim
# MAGIC    - `payment_date`: Date when payment was made
# MAGIC    - `amount_paid`: Amount paid out
# MAGIC    - `payment_method`: Payment method (Check, Wire, ACH, Credit)
# MAGIC
# MAGIC **⚠️ Data Quality Issues to Handle:**
# MAGIC - Missing values (NULL)
# MAGIC - Duplicate records (especially policies and claims)
# MAGIC - Invalid date/timestamp formats
# MAGIC - Out-of-range values (negative amounts, invalid credit scores)
# MAGIC - Inconsistent case (mixed uppercase/lowercase in status, policy types)
# MAGIC - Orphaned records (references to non-existent entities)
# MAGIC - Malformed JSON in `address` field
# MAGIC - **Overlapping policies**: Same customer with multiple active policies for different vehicles
# MAGIC - **Reopened claims**: Claims marked "Closed" but new payouts arrive later
# MAGIC - **High telematics volume**: ~100 rows per policy requiring efficient aggregations
# MAGIC - **Date discrepancies**: Claims with incident_date outside policy coverage period
# MAGIC - **Invalid relationships**: Claims referencing non-existent policies or policies referencing non-existent customers

# COMMAND ----------

# MAGIC %md
# MAGIC ## 🥈 Silver Layer (Your Task)
# MAGIC
# MAGIC Create cleaned and conformed tables in the `insurance_project.silver_schema` schema.
# MAGIC
# MAGIC ### Silver Tables to Create:
# MAGIC
# MAGIC 1. **`dim_customers`** (SCD Type 2 - Slowly Changing Dimension)
# MAGIC    - Purpose: Track customer history. Insurance premiums change based on life events (moving house, getting married, credit score changes). You must track these changes over time to ensure risk is calculated correctly for the period an accident occurred.
# MAGIC    - Include: `customer_id`, `name`, `dob`, `street`, `city`, `state`, `zip_code`, `credit_score`, `occupation`, `valid_from`, `valid_to`, `is_current`
# MAGIC    - Requirements:
# MAGIC      - Clean and standardize customer data from `raw_customers`
# MAGIC      - Handle duplicates (identify same person with name variations and same DOB)
# MAGIC      - Flatten `address` JSON into separate columns (street, city, state, zip_code)
# MAGIC      - Validate dates and handle invalid formats
# MAGIC      - Validate credit_score range (300-850)
# MAGIC      - Implement SCD Type 2 logic for address/credit_score/occupation changes
# MAGIC      - Add `valid_from`, `valid_to`, and `is_current` flags
# MAGIC      - Standardize occupation names (handle case variations)
# MAGIC
# MAGIC 2. **`fact_policy_risk_profile`**
# MAGIC    - Purpose: Aggregates raw_iot_telematics at the policy level to calculate risk scores.
# MAGIC    - Include: `policy_id`, `customer_id`, `policy_type`, `premium_amount`, `start_date`, `end_date`, `coverage_limit`, `vehicle_id`, `total_miles_driven`, `hard_braking_count`, `speeding_events_count` (speed > 80 mph), `risk_score`, `risk_category` (Low/Medium/High)
# MAGIC    - Requirements:
# MAGIC      - Clean policy data from `raw_policies`
# MAGIC      - Join with `dim_customers` to get customer information
# MAGIC      - Aggregate telematics data from `raw_iot_telematics`:
# MAGIC        - Calculate total miles driven (max mileage - min mileage per policy)
# MAGIC        - Count hard braking events per policy
# MAGIC        - Count speeding events (speed > 80 mph) per policy
# MAGIC      - Calculate "Risk Scores" based on frequency of hard braking or speeding per 100 miles:
# MAGIC        - Risk Score = (Hard Braking Count + Speeding Events Count) / (Total Miles / 100)
# MAGIC        - If Total Miles = 0, set Risk Score = 0
# MAGIC      - Categorize risk: Low (0-2), Medium (2-5), High (>5)
# MAGIC      - Handle policies with no telematics data (set risk_score = NULL)
# MAGIC      - Remove orphaned records (customer_id not in dim_customers)
# MAGIC      - Handle overlapping policies (same customer, different vehicles)
# MAGIC
# MAGIC 3. **`fact_claims_lifecycle`**
# MAGIC    - Purpose: Joins raw_claims with raw_payouts and raw_policies to track the complete claim lifecycle.
# MAGIC    - Include: `claim_id`, `policy_id`, `customer_id`, `incident_date`, `filed_date`, `claim_amount`, `status`, `claim_type`, `total_amount_paid`, `payment_count`, `last_payment_date`, `is_valid_claim`, `fraud_flag`
# MAGIC    - Requirements:
# MAGIC      - Clean claim data from `raw_claims`
# MAGIC      - Join with `raw_policies` to get policy information
# MAGIC      - Join with `raw_payouts` to aggregate payment information:
# MAGIC        - Sum all payouts per claim (`total_amount_paid`)
# MAGIC        - Count number of payments (`payment_count`)
# MAGIC        - Get latest payment date (`last_payment_date`)
# MAGIC      - **Validation Check**: A "Silver" quality check must ensure `incident_date` falls between the policy `start_date` and `end_date`. If not, flag it as `fraud_flag = 'Potential Fraud/Invalid Claim'`.
# MAGIC      - Set `is_valid_claim = True` if incident_date is within policy coverage period, else `False`
# MAGIC      - Handle "Reopened" claims: If a claim is marked "Closed" but a new payout arrives later (payment_date > last known status update), update status to "Reopened"
# MAGIC      - Standardize claim status (Open, Closed, Denied, Reopened)
# MAGIC      - Remove orphaned records (policy_id not in fact_policy_risk_profile)
# MAGIC
# MAGIC **Key Techniques to Use:**
# MAGIC - **Auto Loader** with schema evolution for reading JSON files
# MAGIC - **Rescued data column** to capture malformed records
# MAGIC - **PySpark functions**: `filter()`, `when()`, `regexp_replace()`, `to_date()`, `to_timestamp()`, `upper()`, `lower()`, `trim()`, `split()`, `get_json_object()`, `from_json()`
# MAGIC - **Data quality checks**: Validate ranges, formats, and relationships
# MAGIC - **Deduplication**: Use window functions with `row_number()` for customer deduplication
# MAGIC - **SCD Type 2**: Implement using window functions and date logic
# MAGIC - **JSON parsing**: Extract fields from `address` using `get_json_object()` or `from_json()`
# MAGIC - **Aggregations**: Efficient aggregation of high-volume telematics data before joining
# MAGIC - **Window functions**: For identifying reopened claims and calculating risk scores

# COMMAND ----------

# MAGIC %md
# MAGIC ## 🥇 Gold Layer (Your Task)
# MAGIC
# MAGIC Create business intelligence tables in the `insurance_project.gold_schema` schema.
# MAGIC
# MAGIC ### Gold Tables to Create:
# MAGIC
# MAGIC 1. **`kpi_loss_ratio`**
# MAGIC    - Purpose: Calculate Loss Ratio (LR) - the most critical number in the insurance industry
# MAGIC    - Metric: (Total Claims Paid + Claims Reserved) / Total Premiums Collected
# MAGIC    - Include: `date`, `total_premiums_collected`, `total_claims_paid`, `claims_reserved` (Open claims with claim_amount but no payment yet), `loss_ratio_percentage`
# MAGIC    - Requirements:
# MAGIC      - Sum all premium amounts from `fact_policy_risk_profile` (group by date - use policy start_date)
# MAGIC      - Sum all paid amounts from `fact_claims_lifecycle` where status = 'Closed' (group by payment_date)
# MAGIC      - Calculate claims reserved: Sum claim_amount from claims with status = 'Open' or 'Reopened' (group by filed_date)
# MAGIC      - Calculate Loss Ratio: (Total Claims Paid + Claims Reserved) / Total Premiums Collected * 100
# MAGIC      - Group by date (monthly aggregation recommended)
# MAGIC    - Business Value: If Loss Ratio > 100%, the insurance company is losing money on its underwritings.
# MAGIC
# MAGIC 2. **`kpi_claim_processing_lag`**
# MAGIC    - Purpose: Calculate Claim Processing Lag (Cycle Time)
# MAGIC    - Metric: Average days between `filed_date` and `payment_date` (or last_payment_date for multiple payments)
# MAGIC    - Include: `date`, `total_claims_processed`, `avg_processing_days`, `median_processing_days`, `claims_processed_within_30_days`, `claims_processed_over_60_days`
# MAGIC    - Requirements:
# MAGIC      - Join `fact_claims_lifecycle` with payout information
# MAGIC      - Calculate processing time: `last_payment_date - filed_date` in days
# MAGIC      - Filter only claims with status = 'Closed' (completed claims)
# MAGIC      - Calculate average and median processing days
# MAGIC      - Count claims processed within 30 days and over 60 days
# MAGIC      - Group by date (monthly aggregation recommended)
# MAGIC    - Business Value: Long delays lead to poor customer satisfaction and potential legal interest payments.
# MAGIC
# MAGIC 3. **`kpi_premium_leakage_analysis`**
# MAGIC    - Purpose: Identify Premium Leakage - customers with high risk scores paying low premiums
# MAGIC    - Metric: Identification of customers with high "Hard Braking" scores in Silver who are still paying "Low Risk" premiums
# MAGIC    - Include: `customer_id`, `name`, `policy_id`, `risk_score`, `risk_category`, `premium_amount`, `expected_premium_range` (based on risk), `premium_leakage_amount`, `recommendation`
# MAGIC    - Requirements:
# MAGIC      - Join `fact_policy_risk_profile` with `dim_customers`
# MAGIC      - Identify policies where:
# MAGIC        - Risk Category = 'High' but premium_amount is in the bottom 25th percentile
# MAGIC        - OR Risk Score > 5 but premium_amount < $500 (for auto policies)
# MAGIC      - Calculate expected premium range based on risk category:
# MAGIC        - Low Risk: $300-$500
# MAGIC        - Medium Risk: $500-$800
# MAGIC        - High Risk: $800-$1500
# MAGIC      - Calculate premium leakage: `expected_premium_range (midpoint) - current_premium_amount`
# MAGIC      - Add recommendation: "Increase Premium on Renewal" or "Review Policy"
# MAGIC      - Filter only active policies (end_date IS NULL or end_date > current_date)
# MAGIC    - Business Value: Directs the sales team on which policies need price increases upon renewal.
# MAGIC
# MAGIC 4. **`kpi_frequency_severity`**
# MAGIC    - Purpose: Calculate Frequency & Severity metrics
# MAGIC    - Metric: Number of claims per 1,000 policies (Frequency) and Average cost per claim (Severity)
# MAGIC    - Include: `date`, `policy_type`, `total_policies`, `total_claims`, `claims_per_1000_policies` (Frequency), `avg_claim_amount` (Severity), `total_claim_amount`, `median_claim_amount`
# MAGIC    - Requirements:
# MAGIC      - Count total policies from `fact_policy_risk_profile` (group by policy_type and date)
# MAGIC      - Count total claims from `fact_claims_lifecycle` (group by policy_type and date - use incident_date)
# MAGIC      - Calculate Frequency: (Total Claims / Total Policies) * 1000
# MAGIC      - Calculate Severity: Average claim_amount from `fact_claims_lifecycle`
# MAGIC      - Also calculate median claim amount for better understanding of distribution
# MAGIC      - Group by date (monthly aggregation recommended) and policy_type
# MAGIC      - Filter only valid claims (is_valid_claim = True)
# MAGIC    - Business Value: Helps underwriters understand risk exposure by policy type and time period.
# MAGIC
# MAGIC **Key Techniques to Use:**
# MAGIC - **Aggregations**: `groupBy()`, `agg()`, `sum()`, `avg()`, `max()`, `min()`, `count()`, `percentile_approx()`
# MAGIC - **Window functions**: For time-based calculations and percentiles
# MAGIC - **Joins**: Combine fact and dimension tables
# MAGIC - **Date/time functions**: Extract date, calculate time differences, date arithmetic
# MAGIC - **Conditional logic**: `when()`, `case when` for categorizing risk and calculating expected premiums
# MAGIC - **Percentile calculations**: For identifying premium leakage (bottom 25th percentile)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Implementation Guidelines
# MAGIC
# MAGIC ### Step 1: Environment Setup
# MAGIC 1. Run the `01_insurance_data_setup.ipynb` notebook to create bronze data
# MAGIC 2. Create schemas for silver and gold layers:
# MAGIC    ```sql
# MAGIC    CREATE SCHEMA IF NOT EXISTS insurance_project.silver_schema;
# MAGIC    CREATE SCHEMA IF NOT EXISTS insurance_project.gold_schema;
# MAGIC    ```
# MAGIC
# MAGIC ### Step 2: Bronze to Silver Pipeline
# MAGIC 1. Use **Auto Loader** to read JSON files from the volume
# MAGIC 2. Enable **schema evolution** and **rescued data column**
# MAGIC 3. Clean and transform each bronze table
# MAGIC 4. Handle customer deduplication (same DOB, similar names)
# MAGIC 5. Implement SCD Type 2 for dim_customers
# MAGIC 6. Aggregate telematics data efficiently before joining (handle high volume)
# MAGIC 7. Validate claim dates against policy coverage periods
# MAGIC 8. Handle reopened claims logic
# MAGIC 9. Write to Delta tables in silver schema
# MAGIC
# MAGIC ### Step 3: Silver to Gold Pipeline
# MAGIC 1. Read from silver tables
# MAGIC 2. Perform aggregations and calculations for each KPI
# MAGIC 3. Handle overlapping policies in calculations
# MAGIC 4. Calculate risk-based premium expectations
# MAGIC 5. Write to Delta tables in gold schema
# MAGIC
# MAGIC ### Step 4: Data Quality Checks
# MAGIC 1. Validate record counts
# MAGIC 2. Check for NULLs in critical fields
# MAGIC 3. Verify relationships (foreign keys)
# MAGIC 4. Validate calculated metrics (ranges, formats)
# MAGIC 5. Check for duplicate customers resolved correctly
# MAGIC 6. Verify fraud flags are set correctly for invalid claims
# MAGIC 7. Verify risk scores are calculated correctly
# MAGIC
# MAGIC ### Code Structure Example:
# MAGIC ```python
# MAGIC # Read bronze data with Auto Loader
# MAGIC bronze_df = (spark.readStream
# MAGIC     .format("cloudFiles")
# MAGIC     .option("cloudFiles.format", "json")
# MAGIC     .option("cloudFiles.schemaLocation", "/path/to/schema")
# MAGIC     .option("cloudFiles.schemaEvolutionMode", "addNewColumns")
# MAGIC     .option("rescuedDataColumn", "_rescued_data")
# MAGIC     .load("/Volumes/insurance_project/bronze_schema/raw/policies"))
# MAGIC
# MAGIC # Clean and transform
# MAGIC silver_df = (bronze_df
# MAGIC     .filter(col("policy_id").isNotNull())
# MAGIC     .withColumn("policy_type", trim(upper(col("policy_type"))))
# MAGIC     .dropDuplicates(["policy_id"]))
# MAGIC
# MAGIC # Write to Delta
# MAGIC (silver_df.writeStream
# MAGIC     .format("delta")
# MAGIC     .option("checkpointLocation", "/path/to/checkpoint")
# MAGIC     .table("insurance_project.silver_schema.fact_policy_risk_profile"))
# MAGIC ```

# COMMAND ----------

# MAGIC %md
# MAGIC ## Deliverables
# MAGIC
# MAGIC 1. **Silver Layer Tables** (3 tables):
# MAGIC    - `dim_customers` (SCD Type 2)
# MAGIC    - `fact_policy_risk_profile`
# MAGIC    - `fact_claims_lifecycle`
# MAGIC
# MAGIC 2. **Gold Layer Tables** (4 tables):
# MAGIC    - `kpi_loss_ratio`
# MAGIC    - `kpi_claim_processing_lag`
# MAGIC    - `kpi_premium_leakage_analysis`
# MAGIC    - `kpi_frequency_severity`
# MAGIC
# MAGIC 3. **Documentation**:
# MAGIC    - Explain your data cleaning approach
# MAGIC    - Document how you handled customer deduplication
# MAGIC    - Describe your SCD Type 2 implementation
# MAGIC    - Explain how you handled overlapping policies
# MAGIC    - Document how you identified and handled reopened claims
# MAGIC    - Describe how you aggregated high-volume telematics data efficiently
# MAGIC    - Explain your risk score calculation logic
# MAGIC    - Document how you validated claims against policy coverage periods
# MAGIC    - Describe any assumptions made
# MAGIC    - Explain how you handled data quality issues
# MAGIC    - Explain your KPI calculation logic
# MAGIC
# MAGIC 4. **Data Quality Report**:
# MAGIC    - Number of records processed
# MAGIC    - Number of records filtered/dropped
# MAGIC    - Number of rescued records
# MAGIC    - Number of duplicate customers identified and resolved
# MAGIC    - Number of overlapping policies identified
# MAGIC    - Number of reopened claims identified
# MAGIC    - Number of invalid claims (fraud flags)
# MAGIC    - Number of policies with no telematics data
# MAGIC    - Data quality metrics

# COMMAND ----------

# MAGIC %md
# MAGIC ## Evaluation Criteria
# MAGIC
# MAGIC 1. **Data Quality** (40%):
# MAGIC    - Proper handling of missing values
# MAGIC    - Duplicate removal (especially customer deduplication)
# MAGIC    - Data type conversions
# MAGIC    - Validation of ranges and formats
# MAGIC    - Use of rescued data column
# MAGIC    - Handling of overlapping policies
# MAGIC    - Validation of claims against policy coverage periods
# MAGIC
# MAGIC 2. **Data Modeling** (30%):
# MAGIC    - Correct SCD Type 2 implementation
# MAGIC    - Proper dimension and fact table design
# MAGIC    - Appropriate joins and relationships
# MAGIC    - Customer deduplication logic
# MAGIC    - JSON flattening (address field)
# MAGIC    - Efficient aggregation of telematics data
# MAGIC    - Proper handling of reopened claims
# MAGIC
# MAGIC 3. **Business Logic** (20%):
# MAGIC    - Correct KPI calculations
# MAGIC    - Accurate risk score calculations
# MAGIC    - Proper handling of overlapping policies in KPIs
# MAGIC    - Correct fraud flag logic
# MAGIC    - Accurate aggregations
# MAGIC    - Proper date/time handling
# MAGIC
# MAGIC 4. **Code Quality** (10%):
# MAGIC    - Clean, readable code
# MAGIC    - Proper use of PySpark functions
# MAGIC    - Efficient transformations (especially for high-volume telematics)
# MAGIC    - Comments and documentation

# COMMAND ----------

# MAGIC %md
# MAGIC ## Tips and Best Practices
# MAGIC
# MAGIC 1. **Start with Bronze to Silver**: Focus on cleaning one table at a time, starting with `dim_customers`
# MAGIC 2. **Customer Deduplication**: Use DOB + name similarity to identify duplicate customers
# MAGIC 3. **SCD Type 2**: Track changes in customer address/credit_score/occupation over time using window functions
# MAGIC 4. **Telematics Aggregation**: Aggregate telematics data at the policy level BEFORE joining to fact table to handle high volume efficiently
# MAGIC 5. **Overlapping Policies**: Ensure claims are linked to the correct policy/vehicle when a customer has multiple active policies
# MAGIC 6. **Reopened Claims**: Check if a "Closed" claim has new payouts arriving after the close date
# MAGIC 7. **Fraud Validation**: Always validate that incident_date falls within policy start_date and end_date
# MAGIC 8. **Test Incrementally**: Verify each transformation step
# MAGIC 9. **Handle Edge Cases**: NULL values, empty strings, extreme values, invalid dates, policies with no telematics data
# MAGIC 10. **Use Rescued Data**: Check `_rescued_data` column for malformed records
# MAGIC 11. **Optimize Joins**: Use broadcast joins for small dimension tables
# MAGIC 12. **Partition Strategically**: Partition fact tables by date for better performance
# MAGIC 13. **Document Assumptions**: Note any business logic decisions (e.g., risk score thresholds, premium ranges)
# MAGIC 14. **Validate Results**: Check record counts and sample data after each step
# MAGIC
# MAGIC ## Resources
# MAGIC
# MAGIC - [Databricks Auto Loader Documentation](https://docs.databricks.com/ingestion/auto-loader/index.html)
# MAGIC - [Delta Lake Documentation](https://docs.delta.io/)
# MAGIC - [PySpark SQL Functions](https://spark.apache.org/docs/latest/api/python/reference/pyspark.sql/functions.html)
# MAGIC - [Medallion Architecture](https://www.databricks.com/glossary/medallion-architecture)
# MAGIC - [SCD Type 2 Implementation](https://www.databricks.com/blog/2022/11/30/implementing-slowly-changing-dimensions-scd-type-2-using-delta-lake.html)
# MAGIC
# MAGIC ---